<?php
include_once("../config.php");

$db = $mysqli ?? $koneksi ?? null;
if (!$db) {
    die('Database connection not found');
}

$nis = $_POST['nis'] ?? $_GET['nis'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($nis)) {
        die('NIS tidak ditemukan.');
    }

    $nama_lengkap = $_POST['nama_lengkap'] ?? '';
    $jurusan = $_POST['jurusan'] ?? '';
    $nomer_telepon = $_POST['nomer_telepon'] ?? '';
    $nama_tim = $_POST['nama_tim'] ?? '';
    $role = $_POST['role'] ?? '';

    $stmt = $db->prepare("UPDATE tb_siswa SET nama_lengkap=?, jurusan=?, nomer_telepon=?, nama_tim=?, role=? WHERE nis=?");
    if (!$stmt) {
        die('Prepare failed (UPDATE): ' . $db->error);
    }
    // six placeholders: nama_lengkap, jurusan, nomer_telepon, nama_tim, role, nis
    $stmt->bind_param('ssssss', $nama_lengkap, $jurusan, $nomer_telepon, $nama_tim, $role, $nis);

    if ($stmt->execute()) {
        echo '<!DOCTYPE html><html><head>';
        echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
        echo '</head><body>';
        echo '<script>
            Swal.fire({
                icon: "success",
                title: "Data berhasil diubah!",
                text: "Anda akan diarahkan ke halaman Data Siswa.",
                timer: 1500,
                showConfirmButton: false
            }).then(function(){ window.location.href = "simple.php"; });
        </script>';
        echo '</body></html>';
        exit;
    } else {
        $err = htmlspecialchars($stmt->error, ENT_QUOTES);
        echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>';
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Gagal',
                text: 'Gagal update: {$err}'
            });
        </script>";
        exit;
    }
}

if ($nis) {
    $stmt = $db->prepare("SELECT nis, nama_lengkap, jurusan, nomer_telepon, nama_tim, role FROM tb_siswa WHERE nis = ?");
    if (!$stmt) {
        die('Prepare failed (SELECT): ' . $db->error);
    }
    $stmt->bind_param('s', $nis);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();

    if (!$row) {
        die('Data tidak ditemukan.');
    }

    $nama_lengkap = $row['nama_lengkap'];
    $jurusan = $row['jurusan'];
    $nomer_telepon = $row['nomer_telepon'];
    $nama_tim = $row['nama_tim'];
    $role = $row['role'];
} else {
    die('NIS tidak disertakan di URL.');
}
?>




<!doctype html>
<html lang="en">
<!--begin::Head-->

<head>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>AdminLTE 4 | Simple Tables</title>
    <!--begin::Accessibility Meta Tags-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="color-scheme" content="light dark" />
    <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
    <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
    <!--end::Accessibility Meta Tags-->
    <!--begin::Primary Meta Tags-->
    <meta name="title" content="AdminLTE 4 | Simple Tables" />
    <meta name="author" content="ColorlibHQ" />
    <meta
        name="description"
        content="AdminLTE is a Free Bootstrap 5 Admin Dashboard, 30 example pages using Vanilla JS. Fully accessible with WCAG 2.1 AA compliance." />
    <meta
        name="keywords"
        content="bootstrap 5, bootstrap, bootstrap 5 admin dashboard, bootstrap 5 dashboard, bootstrap 5 charts, bootstrap 5 calendar, bootstrap 5 datepicker, bootstrap 5 tables, bootstrap 5 datatable, vanilla js datatable, colorlibhq, colorlibhq dashboard, colorlibhq admin dashboard, accessible admin panel, WCAG compliant" />
    <!--end::Primary Meta Tags-->
    <!--begin::Accessibility Features-->
    <!-- Skip links will be dynamically added by accessibility.js -->
    <meta name="supported-color-schemes" content="light dark" />
    <link rel="preload" href="../../css/adminlte.css" as="style" />
    <!--end::Accessibility Features-->
    <!--begin::Fonts-->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
        integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q="
        crossorigin="anonymous"
        media="print"
        onload="this.media='all'" />
    <!--end::Fonts-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(OverlayScrollbars)-->
    <!--begin::Third Party Plugin(Bootstrap Icons)-->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
        crossorigin="anonymous" />
    <!--end::Third Party Plugin(Bootstrap Icons)-->
    <!--begin::Required Plugin(AdminLTE)-->
    <link rel="stylesheet" href="../css/adminlte.css" />
    <!--end::Required Plugin(AdminLTE)-->
</head>
<!--end::Head-->
<!--begin::Body-->

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
    <!--begin::App Wrapper-->
    <div class="app-wrapper">
        <!--begin::Header-->
        <nav class="app-header navbar navbar-expand bg-body">
            <!--begin::Container-->
            <div class="container-fluid">
                <!--begin::Start Navbar Links-->
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                            <i class="bi bi-list"></i>
                        </a>
                    </li>
                    
                            <!--end::Menu Footer-->
                        </ul>
                    </li>
                    <!--end::User Menu Dropdown-->
                </ul>
                <!--end::End Navbar Links-->
            </div>
            <!--end::Container-->
        </nav>
        <!--end::Header-->
        <!--begin::Sidebar-->
        <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
            <!--begin::Sidebar Brand-->
            <div class="sidebar-brand">
                <!--begin::Brand Link-->
                <a href="daftar.php" class="brand-link">
                    <!--begin::Brand Image-->
                    <img
                        src="../image/LOGO.png"
                        alt="pubg logo"
                        class="brand-image opacity-75 shadow" />
                    <!--end::Brand Image-->
                    <!--begin::Brand Text-->
                    <span class="brand-text fw-light">Turnamen PUBG 2025</span>
                    <!--end::Brand Text-->
                </a>
                <!--end::Brand Link-->
            </div>
            <!--end::Sidebar Brand-->
            <!--begin::Sidebar Wrapper-->
            <div class="sidebar-wrapper">
                <nav class="mt-2">
                    <!--begin::Sidebar Menu-->
                    <ul
                        class="nav sidebar-menu flex-column"
                        data-lte-toggle="treeview"
                        role="navigation"
                        aria-label="Main navigation"
                        data-accordion="false"
                        id="navigation">
                        <li class="nav-item">
                            <ul class="nav sidebar-menu flex-column" data-bs-toggle="treeview"
                                role="navigation"
                                aria-label="Main navigation"
                                data-accordion="false"
                                id="navigation">

                                <li class="nav-item">
                                    <a href="../index.php" class="nav-link">
                                        <i class="nav-icon bi bi-house"></i>
                                        <p>Dashboard</p>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a href="simple.php" class="nav-link">
                                        <i class="nav-icon bi bi-star-half"></i>
                                        <p>Data Siswa</p>
                                    </a>
                                        
                                </li>
                            </ul>

                    </ul>
                    <!--end::Sidebar Menu-->
                </nav>
            </div>
            <!--end::Sidebar Wrapper-->
        </aside>
        <!--end::Sidebar-->
        <!--begin::App Main-->
        <main class="app-main">
            <!--begin::App Content Header-->
            <div class="app-content-header">
                <!--begin::Container-->
                <div class="container-fluid">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-sm-6">
                            <h3 class="mb-0">Edit</h3>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-end">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Data Siswa</li>
                            </ol>
                        </div>
                    </div>
                    <!--end::Row--> 
                </div>
                <!--end::Container-->
            </div>
            <!--end::App Content Header-->
            <!--begin::App Content-->
            <div class="app-content">
                <!--begin::Container-->
                <div class="card card-warning card-outline mb-4">
                    <!--begin::Header-->
                    <div class="card-header">
                        <div class="card-title">Form untuk menambahkan peserta didik baru</div>
                    </div>
                    <!--end::Header-->
                    <!--begin::Form-->
                    <form method="post" action="edit.php">
                        <!--begin::Body-->
                        <div class="card-body">
                            <div class="row mb-3">
                                <label for="inputnisl3" class="col-sm-2 col-form-label">Nis</label>
                                <div class="col-sm-10">
                                    <!-- readonly supaya tidak bisa diubah tapi tetap dikirim -->
                                    <input placeholder="Nis Tidak Dapat Diubah" name="nis" type="text" class="form-control" id="inputnisl3" readonly value="<?php echo htmlspecialchars($nis ?? ''); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="inputnamal3" class="col-sm-2 col-form-label">Username</label>
                                <div class="col-sm-10">
                                    <input placeholder="Masukan Username" name="nama_lengkap" type="text" class="form-control" id="inputnamal3" value="<?php echo htmlspecialchars($nama_lengkap ?? ''); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="inputjurusanl3" class="col-sm-2 col-form-label">Jurusan</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="inputjurusanl3" name="jurusan">
                                        <option value="">Pilih Jurusan.</option>
                                        <option value="Pengembangan Perangkat Lunak dan Gim" <?php echo (isset($jurusan) && $jurusan === 'Pengembangan Perangkat Lunak dan Gim') ? 'selected' : ''; ?>>Pengembangan Perangkat Lunak dan Gim</option>
                                        <option value="Desain Komunikasi Visual" <?php echo (isset($jurusan) && $jurusan === 'Desain Komunikasi Visual') ? 'selected' : ''; ?>>Desain Komunikasi Visual</option>
                                        <option value="Teknik Jaringan Komputer Telekomunikasi" <?php echo (isset($jurusan) && $jurusan === 'Teknik Jaringan Komputer Telekomunikasi') ? 'selected' : ''; ?>>Teknik Jaringan Komputer Telekomunikasi</option>
                                        <option value="Bisnis Digital" <?php echo (isset($jurusan) && $jurusan === 'Bisnis Digital') ? 'selected' : ''; ?>>Bisnis Digital</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="inputnol3" class="col-sm-2 col-form-label">No. Telepon</label>
                                <div class="col-sm-10">
                                    <input placeholder="Masukan No.Telepon" name="nomer_telepon" type="text" class="form-control" id="inputnol3" value="<?php echo htmlspecialchars($nomer_telepon ?? ''); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="inputcital3" class="col-sm-2 col-form-label">nama_tim</label>
                                <div class="col-sm-10">
                                    <input placeholder="Masukan nama_tim" name="nama_tim" type="text" class="form-control" id="inputcital3" value="<?php echo htmlspecialchars($nama_tim ?? ''); ?>">
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="inputrolel3" class="col-sm-2 col-form-label">Role</label>
                                <div class="col-sm-10">
                                    <select class="form-control" id="inputrolel3" name="role">
                                        <option value="">Pilih Role.</option>
                                        <option value="Rusher" <?php echo (isset($role) && $role === 'Rusher') ? 'selected' : ''; ?>>Rusher</option>
                                        <option value="Sniper" <?php echo (isset($role) && $role === 'Sniper') ? 'selected' : ''; ?>>Sniper</option>
                                        <option value="Scout" <?php echo (isset($role) && $role === 'Scout') ? 'selected' : ''; ?>>Scout</option>
                                        <option value="Support" <?php echo (isset($role) && $role === 'Support') ? 'selected' : ''; ?>>Support</option>
                                    </select>
                                </div>
                        </div>
                        <!--end::Body-->
                        <!--begin::Footer-->
                        <div class="card-footer">
                            <button type="submit" name="submit" class="btn btn-primary mb-2">Simpan</button>
                            <a href="simple.php" class="btn float-end">Cancel</a>
                        </div>
                        <!--end::Footer-->
                    </form>
                    <!--end::Form-->
                </div>
            </div>
            <!-- /.card -->
        </main>
        <!--end::App Main-->
        <!--begin::Footer-->
        <footer class="app-footer">
            <!--begin::To the end-->
            <div class="float-end d-none d-sm-inline"></div>
            <!--end::To the end-->
            <!--begin::Copyright-->
            <strong>
                Copyright &copy; 2022-2025&nbsp;
                <a href="../index.php" class="text-decoration-none">Turnamen PUBG 2025</a>.
            </strong>
            All rights reserved.
            <!--end::Copyright-->
        </footer>
        <!--end::Footer-->
    </div>
    <!--end::App Wrapper-->
    <!--begin::Script-->
    <!--begin::Third Party Plugin(OverlayScrollbars)-->
    <script
        src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
        crossorigin="anonymous"></script>
    <!--end::Third Party Plugin(OverlayScrollbars)--><!--begin::Required Plugin(popperjs for Bootstrap 5)-->
    <script
        src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(popperjs for Bootstrap 5)--><!--begin::Required Plugin(Bootstrap 5)-->
    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
        crossorigin="anonymous"></script>
    <!--end::Required Plugin(Bootstrap 5)--><!--begin::Required Plugin(AdminLTE)-->
    <script src="../js/adminlte.js"></script>
    <!--end::Required Plugin(AdminLTE)--><!--begin::OverlayScrollbars Configure-->
    <script>
        const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
        const Default = {
            scrollbarTheme: 'os-theme-light',
            scrollbarAutoHide: 'leave',
            scrollbarClickScroll: true,
        };
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
            if (sidebarWrapper && OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined) {
                OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
                    scrollbars: {
                        theme: Default.scrollbarTheme,
                        autoHide: Default.scrollbarAutoHide,
                        clickScroll: Default.scrollbarClickScroll,
                    },
                });
            }
        });
    </script>
    <!--end::OverlayScrollbars Configure-->
    <!--end::Script-->
</body>
<!--end::Body-->

</html>