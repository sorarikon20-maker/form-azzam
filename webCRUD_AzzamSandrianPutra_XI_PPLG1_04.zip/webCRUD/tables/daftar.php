<?php
// Create database connection using config file
include_once("../config.php");

// Fetch all users data from database
$result = mysqli_query($mysqli, "SELECT * FROM tb_siswa");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Turnamen PUBG 2025</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            width: 100%;
            background-image: url('../image/background.png'); /* GANTI LINK INI */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            font-family: Arial, sans-serif;
            color: white;
        }

        .overlay {
            width: 100%;
            height: 100vh;
            background-color: rgba(0, 0, 0, 0.5); /* gelap transparan */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        h1.title {
            font-size: 80px;
            font-weight: 900;
            letter-spacing: 5px;
            margin: 0;
            color: #ff5c1b;
        }

        h2.sub {
            margin: 0;
            font-size: 22px;
            letter-spacing: 4px;
            color: red;
        }

        .btn {
            margin-top: 40px;
            padding: 15px 40px;
            background-color: #ff5c1b;
            border-radius: 10px;
            color: white;
            font-size: 20px;
            text-decoration: none;
            border: 2px solid #ff8a50;
            transition: 0.3s;
        }

        .btn:hover {
            background-color: #ff8a50;
        }

        .footer {
            position: absolute;
            left: 40px;
            bottom: 40px;
            font-size: 18px;
            letter-spacing: 2px;
        }

    </style>

</head>
<body>

<div class="overlay">

    
    <h1 class="title">DAFTARKAN TIM KALIAN</h1>
    <h2 class="sub">KLIK LINK DI BAWAH INI</h2>

    <a href="add_siswa.php" class="btn">DAFTAR</a>

</div>

<div class="footer">
    
</div>

</body>
</html>
