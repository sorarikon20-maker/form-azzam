<?php
// Create database connection using config file
include_once("../config.php");

// Fetch all users data from database
$result = mysqli_query($mysqli, "SELECT * FROM tb_siswa");
?>



<!doctype html>
<html lang="en">
<!--begin::Head-->

<head>
 


  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Turnamen PUBG 2025</title>

  <!--begin::Accessibility Meta Tags-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <meta name="color-scheme" content="light dark" />
  <meta name="theme-color" content="#007bff" media="(prefers-color-scheme: light)" />
  <meta name="theme-color" content="#1a1a1a" media="(prefers-color-scheme: dark)" />
  <!--end::Accessibility Meta Tags-->
  <!--begin::Primary Meta Tags-->
  <meta name="title" content="AdminLTE 4 | Simple Tables" />
  <meta name="author" content="ColorlibHQ" />
  <meta
    name="description"
    content="AdminLTE is a Free Bootstrap 5 Admin Dashboard, 30 example pages using Vanilla JS. Fully accessible with WCAG 2.1 AA compliance." />
  <meta
    name="keywords"
    content="bootstrap 5, bootstrap, bootstrap 5 admin dashboard, bootstrap 5 dashboard, bootstrap 5 charts, bootstrap 5 calendar, bootstrap 5 datepicker, bootstrap 5 tables, bootstrap 5 datatable, vanilla js datatable, colorlibhq, colorlibhq dashboard, colorlibhq admin dashboard, accessible admin panel, WCAG compliant" />
  <!--end::Primary Meta Tags-->
  <!--begin::Accessibility Features-->
  <!-- Skip links will be dynamically added by accessibility.js -->
  <meta name="supported-color-schemes" content="light dark" />
  <link rel="preload" href="../../css/adminlte.css" as="style" />
  <!--end::Accessibility Features-->
  <!--begin::Fonts-->
  <link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/@fontsource/source-sans-3@5.0.12/index.css"
    integrity="sha256-tXJfXfp6Ewt1ilPzLDtQnJV4hclT9XuaZUKyUvmyr+Q="
    crossorigin="anonymous"
    media="print"
    onload="this.media='all'" />
  <!--end::Fonts-->
  <!--begin::Third Party Plugin(OverlayScrollbars)-->
  <link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css"
    crossorigin="anonymous" />
  <!--end::Third Party Plugin(OverlayScrollbars)-->
  <!--begin::Third Party Plugin(Bootstrap Icons)-->
  <link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"
    crossorigin="anonymous" />
  <!--end::Third Party Plugin(Bootstrap Icons)-->
  <!--begin::Required Plugin(AdminLTE)-->
  <link rel="stylesheet" href="../css/adminlte.css" />
  <!--end::Required Plugin(AdminLTE)-->
</head>
<!--end::Head-->
<!--begin::Body-->

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
  <!--begin::App Wrapper-->
  <div class="app-wrapper">
    <!--begin::Header-->
    <nav class="app-header navbar navbar-expand bg-body">
      <!--begin::Container-->
      <div class="container-fluid">
        <!--begin::Start Navbar Links-->
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
              <i class="bi bi-list"></i>
            </a>
          </li>
          
       
              <!--end::Menu Footer-->
            </ul>
          </li>
          <!--end::User Menu Dropdown-->
        </ul>
        <!--end::End Navbar Links-->
      </div>
      <!--end::Container-->
    </nav>
    <!--end::Header-->
    <!--begin::Sidebar-->
    <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
      <!--begin::Sidebar Brand-->
      <div class="sidebar-brand">
        <!--begin::Brand Link-->
        <a href="daftar.php" class="brand-link">
          <!--begin::Brand Image-->
          <img
            src="../image/logo.png"
            alt="pubg Logo"
            class="brand-image opacity-75 shadow" />
          <!--end::Brand Image-->
          <!--begin::Brand Text-->
          <span class="brand-text fw-light">Turnamen PUBG 2025</span>
          <!--end::Brand Text-->
        </a>
        <!--end::Brand Link-->
      </div>
      <!--end::Sidebar Brand-->
      <!--begin::Sidebar Wrapper-->
      <div class="sidebar-wrapper">
        <nav class="mt-2">
          <!--begin::Sidebar Menu-->
          <ul
            class="nav sidebar-menu flex-column"
            data-lte-toggle="treeview"
            role="navigation"
            aria-label="Main navigation"
            data-accordion="false"
            id="navigation">
            <li class="nav-item">
              <ul class="nav sidebar-menu flex-column" data-bs-toggle="treeview"
                role="navigation"
                aria-label="Main navigation"
                data-accordion="false"
                id="navigation">

                <li class="nav-item">
                  <a href="../index.php" class="nav-link">
                    <i class="nav-icon bi bi-house"></i>
                    <p>Dashboard</p>
                  </a>
                </li>

                <li class="nav-item">
                  <a href="simple.php" class="nav-link">
                    <i class="nav-icon bi bi-star-half"></i>
                    <p>Data Pemain Turnamen</p>
                  </a>
                      
                </li>
              </ul>

          </ul>
          <!--end::Sidebar Menu-->
        </nav>
      </div>
      <!--end::Sidebar Wrapper-->
    </aside>
    <!--end::Sidebar-->
    <!--begin::App Main-->
    <main class="app-main">
      <!--begin::App Content Header-->
      <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
          <!--begin::Row-->
          <div class="row">
            <div class="col-sm-6">
              <h3 class="mb-0">Data pemain turnamen</h3>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-end">
                <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Data pemain turnamen</li>
              </ol>
            </div>
          </div>
          <!--end::Row-->
        </div>
        <!--end::Container-->
      </div>
      <!--end::App Content Header-->
      <!--begin::App Content-->
      <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
          <!--begin::Row-->
          <div class="row">
            <div class="col-md-">
              <div class="card mb-4">

                <!-- /.card-header -->
                <div class="card-body">
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th style="width: 10px">NIS</th>
                        <th>Username  </th>
                        <th>Jurusan</th>
                        <th>Nomor Telepon</th>
                        <th>Nama Tim</th>
                        <th>Role</th>
                        <th style="width: 150px">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <a href="add_siswa.php" type="button" class="btn btn-primary mb-2" fdprocessedid="142pua">Tambah</a>
                      <?php
                      $no = 1;
                      while ($siswa_data = mysqli_fetch_array($result)) {
                        $no++;
                        $dataHref = "delete.php?id_siswa=" . urlencode($siswa_data['nis']);
                        echo "<tr class='align-middle'>";
                        echo "<td>" . ($no - 1) . "</td>";
                        echo "<td>" . htmlspecialchars($siswa_data['nis']) . "</td>";
                        echo "<td>" . htmlspecialchars($siswa_data['nama_lengkap']) . "</td>";
                        echo "<td>" . htmlspecialchars($siswa_data['jurusan']) . "</td>";
                        echo "<td>" . htmlspecialchars($siswa_data['nomer_telepon']) . "</td>";
                        echo "<td>" . htmlspecialchars($siswa_data['nama_tim']) . "</td>";
                        echo "<td>" . htmlspecialchars($siswa_data['role']) . "</td>";
                        echo "<td>
                                <a href='edit.php?nis=" . urlencode($siswa_data['nis']) . "'>Edit</a> |
                                <a href='#' class='btn-delete text-danger' data-href='{$dataHref}' data-name='" . htmlspecialchars($siswa_data['nama_lengkap'], ENT_QUOTES) . "'>Delete</a>
                              </td></tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.card-body -->
                
              <!-- /.card -->

              <!--end::App Content-->
    </main>
    <!--end::App Main-->
    <!--begin::Footer-->
    <footer class="app-footer">
      <!--begin::To the end-->
      
      <!--end::To the end-->
      <!--begin::Copyright-->
       <strong>
                Copyright &copy; 2022-2025&nbsp;
                <a href="../index.php" class="text-decoration-none">Turnamen PUBG 2025</a>.
            </strong>
            All rights reserved.
            <!--end::Copyright-->
    </footer>
    <!--end::Footer-->
  </div>
  <!--end::App Wrapper-->
  <!--begin::Script-->
  <!--begin::Third Party Plugin(OverlayScrollbars)-->
  <!-- SweetAlert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script
    src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>
  <!--end::Third Party Plugin(OverlayScrollbars)--><!--begin::Required Plugin(popperjs for Bootstrap 5)-->
  <script
    src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>
  <!--end::Required Plugin(popperjs for Bootstrap 5)--><!--begin::Required Plugin(Bootstrap 5)-->
  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
    crossorigin="anonymous"></script>
  <!--end::Required Plugin(Bootstrap 5)--><!--begin::Required Plugin(AdminLTE)-->
  <script src="../js/adminlte.js"></script>
  <!--end::Required Plugin(AdminLTE)--><!--begin::OverlayScrollbars Configure-->
  <script>
    const SELECTOR_SIDEBAR_WRAPPER = '.sidebar-wrapper';
    const Default = {
      scrollbarTheme: 'os-theme-light',
      scrollbarAutoHide: 'leave',
      scrollbarClickScroll: true,
    };
    document.addEventListener('DOMContentLoaded', function() {
      const sidebarWrapper = document.querySelector(SELECTOR_SIDEBAR_WRAPPER);
      if (sidebarWrapper && OverlayScrollbarsGlobal?.OverlayScrollbars !== undefined) {
        OverlayScrollbarsGlobal.OverlayScrollbars(sidebarWrapper, {
          scrollbars: {
            theme: Default.scrollbarTheme,
            autoHide: Default.scrollbarAutoHide,
            clickScroll: Default.scrollbarClickScroll,
          },
        });
      }
    });
  </script>
  <!--end::OverlayScrollbars Configure-->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // konfirmasi sebelum hapus
      document.querySelectorAll('.btn-delete').forEach(function(el){
        el.addEventListener('click', function(e){
          e.preventDefault();
          const href = el.getAttribute('data-href');
          const name = el.getAttribute('data-name') || '';
          Swal.fire({
            title: 'Hapus data?',
            text: name ? 'Hapus data siswa: ' + name + ' ?' : 'Data akan dihapus.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, hapus',
            cancelButtonText: 'Batal'
          }).then((result) => {
            if (result.isConfirmed) {
              // arahkan ke delete.php yang akan melakukan proses hapus
              window.location.href = href;
            }
          });
        });
      });

      // tampilkan notifikasi hasil hapus bila ada query param ?deleted=1 atau ?deleted=0
      const params = new URLSearchParams(window.location.search);
      if (params.get('deleted') === '1') {
        Swal.fire({
          icon: 'success',
          title: 'Berhasil',
          text: 'Data telah dihapus',
          timer: 1500,
          showConfirmButton: false
        }).then(() => {
          // hapus query string agar pesan tidak muncul lagi saat reload
          history.replaceState({}, document.title, location.pathname);
        });
      } else if (params.get('deleted') === '0') {
        Swal.fire({
          icon: 'error',
          title: 'Gagal',
          text: 'Data gagal dihapus'
        }).then(() => {
          history.replaceState({}, document.title, location.pathname);
        });
      }
    });
  </script>
  <!--end::Script-->
</body>
<!--end::Body-->

</html>