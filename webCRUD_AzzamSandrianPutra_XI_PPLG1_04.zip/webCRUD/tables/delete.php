<?php
include_once("../config.php");
$nis = $_GET['id_siswa'] ?? '';
if ($nis === '') {
    header('Location: simple.php?deleted=0');
    exit;
}
$db = $mysqli ?? $koneksi ?? null;
if (!is_object($db) || !method_exists($db, 'prepare')) {
    // Database connection not available or invalid — abort and return a failure state.
    header('Location: simple.php?deleted=0');
    exit;
}
$stmt = $db->prepare("DELETE FROM tb_siswa WHERE nis = ?");

$stmt->bind_param('s', $nis);
if ($stmt->execute()) {
    header('Location: simple.php?deleted=1');
    exit;
} else {
    header('Location: simple.php?deleted=0');
    exit;
}
?>